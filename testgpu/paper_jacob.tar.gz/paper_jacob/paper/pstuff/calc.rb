def nextgf gf
	inp = gf.gets
	gf.gets
	gf.gets
	gf.gets
	gf.gets
	gf.gets
	return (inp[0...-2]).to_f
end

def avetime times
	inp = times.gets[0...-2].to_f
	times.gets
	return inp
end

def nextfile1 file1
	pnum = 0
	counter = 0
	while inp = file1.gets
		pnum += inp.split[3].to_f
		counter = counter + 1
		if inp[0].chr == 'E'
			file1.gets
			break
		end
	end
	if pnum == 0
		return nil
	end
	return pnum/counter
end

def startfile1 file1
	while inp = file1.gets
		if inp[0].chr == 'B'
			break
		end
	end
end

print "["
file1 = open "file1"
gf = open "gf"
times = open "times"
startfile1 file1
commas = false
loop{
	pnum = nextfile1 file1
	if pnum.nil?
		break
	end
	if commas
		print ","
	else
		commas = true
	end
	gnum = nextgf gf
	tnum = avetime times
	print (gnum*1000)/(pnum*tnum)
}
print "]"
