#!/bin/bash
./getpower.sh &
./baseline 16 512
for j in {4..16};
do
	echo Beginning $j >> file1
	./baseline $j 512
	echo ,
	echo ""
	echo Ending $j >> file1
done
kill `ps aux | grep getpower | grep -v grep | awk '{ print $2 }'`
