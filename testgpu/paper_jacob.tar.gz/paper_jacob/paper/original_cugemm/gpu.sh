#!/bin/bash
typeset -i i iEnd iStep j jEnd jStep k kEnd kStep l lEnd lStep

let i=8 iEnd=16 iStep=8
while ((i<=iEnd)); 
do

	let j=16 jEnd=16384 jStep=2
	while ((j<=jEnd));
	do

		./baseline $i $j
	
	let j*=jStep
	done

let i+=iStep
done

