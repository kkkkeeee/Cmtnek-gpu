#!/bin/bash
while :
do
	nvidia-smi -q -d POWER -i 0 | grep "Power Draw" >> file1
	sleep 1;
done
