#!/bin/bash
typeset -i i iEnd iStep j jEnd jStep k kEnd kStep l lEnd lStep

echo -n [
let i=4 iEnd=16 iStep=1
while ((i<=iEnd)); 
do

		./baseline $i 512
		echo -n ,

let i+=iStep
done
echo ]

