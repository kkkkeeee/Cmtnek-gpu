#!/bin/bash
./getpower.sh &
for j in {4..16};
do
	./baseline $j 512
done
kill `ps aux | grep getpower | grep -v grep | awk '{ print $2 }'`
